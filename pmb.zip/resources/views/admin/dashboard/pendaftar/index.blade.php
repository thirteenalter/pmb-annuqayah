<x-app-layout>
 <x-subnavbaradmin />
  <div class="mx-auto max-w-7xl py-10">
    lish pendaftar admin
  </div>
</x-app-layout>