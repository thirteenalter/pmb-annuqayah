<img class="w-40"
  src="https://pmb.ua.ac.id/wp-content/uploads/2025/01/cropped-1.-Logo-Alternatif-Universitas-Annuqayah.png"
  alt="Logo Universitas Annuqayah">